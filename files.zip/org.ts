// Organisation profile types — mirrors Supabase schema

export type OrgType =
  | 'unincorporated_association'
  | 'company_limited_by_guarantee'
  | 'community_interest_company'
  | 'cooperative'
  | 'registered_charity'
  | 'sports_club'
  | 'school_education'
  | 'public_body'
  | 'other';

export type OrgSetting = 'rural' | 'urban' | 'peri_urban';

export type BudgetRange =
  | 'under_5k'
  | '5k_25k'
  | '25k_100k'
  | '100k_500k'
  | 'over_500k';

export type GeographicReach = 'parish' | 'county' | 'regional' | 'national';

export interface Organisation {
  id: string;
  user_id: string;

  // Identity
  name: string;
  org_type: OrgType;
  org_type_other?: string;
  description?: string;
  year_established?: number;
  website?: string;

  // Registration
  is_registered_charity: boolean;
  charity_number?: string;
  cro_number?: string;

  // Location
  county: string;
  town_area?: string;
  eircode?: string;
  setting: OrgSetting;

  // Contact
  contact_name?: string;
  contact_email?: string;
  contact_phone?: string;
  contact_role?: string;

  // Capacity
  member_count?: number;
  volunteer_count?: number;
  paid_staff_count: number;
  budget_range?: BudgetRange;
  has_bank_account: boolean;
  has_governance_docs: boolean;
  has_insurance: boolean;

  // Activity & Focus
  activity_areas: string[];
  target_demographics: string[];
  geographic_reach?: GeographicReach;

  // Grant Experience
  has_previous_grants: boolean;
  previous_grant_details?: string;

  // Calculated
  profile_completeness: number;

  // Metadata
  created_at: string;
  updated_at: string;
}

// Form state (subset — no id, user_id, timestamps)
export type OrgProfileFormData = Omit<
  Organisation,
  'id' | 'user_id' | 'profile_completeness' | 'created_at' | 'updated_at'
>;

// Section keys for the multi-section form
export type ProfileSection =
  | 'identity'
  | 'location'
  | 'contact'
  | 'capacity'
  | 'activities'
  | 'grants';
