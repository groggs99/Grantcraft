-- GrantCraft: Stage 1 — Organisation Profiles
-- Migration: 001_create_organisations

-- Organisation types matching Irish legal structures
CREATE TYPE org_type AS ENUM (
  'unincorporated_association',
  'company_limited_by_guarantee',
  'community_interest_company',
  'cooperative',
  'registered_charity',
  'sports_club',
  'school_education',
  'public_body',
  'other'
);

CREATE TYPE org_setting AS ENUM (
  'rural',
  'urban',
  'peri_urban'
);

CREATE TYPE budget_range AS ENUM (
  'under_5k',
  '5k_25k',
  '25k_100k',
  '100k_500k',
  'over_500k'
);

CREATE TABLE organisations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  
  -- Identity
  name TEXT NOT NULL,
  org_type org_type NOT NULL DEFAULT 'unincorporated_association',
  org_type_other TEXT, -- if org_type = 'other'
  description TEXT,
  year_established INTEGER,
  website TEXT,
  
  -- Registration
  is_registered_charity BOOLEAN DEFAULT FALSE,
  charity_number TEXT,
  cro_number TEXT, -- Companies Registration Office
  
  -- Location
  county TEXT NOT NULL,
  town_area TEXT,
  eircode TEXT,
  setting org_setting DEFAULT 'rural',
  
  -- Contact
  contact_name TEXT,
  contact_email TEXT,
  contact_phone TEXT,
  contact_role TEXT,
  
  -- Capacity
  member_count INTEGER,
  volunteer_count INTEGER,
  paid_staff_count INTEGER DEFAULT 0,
  budget_range budget_range,
  has_bank_account BOOLEAN DEFAULT FALSE,
  has_governance_docs BOOLEAN DEFAULT FALSE, -- constitution, rules, etc.
  has_insurance BOOLEAN DEFAULT FALSE,
  
  -- Activity & Focus
  activity_areas TEXT[] DEFAULT '{}', -- array of activity area slugs
  target_demographics TEXT[] DEFAULT '{}', -- who they serve
  geographic_reach TEXT, -- parish, county, regional, national
  
  -- Grant Experience
  has_previous_grants BOOLEAN DEFAULT FALSE,
  previous_grant_details TEXT,
  
  -- Profile completeness (calculated)
  profile_completeness INTEGER DEFAULT 0, -- 0-100
  
  -- Metadata
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for user lookups
CREATE INDEX idx_organisations_user_id ON organisations(user_id);

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER organisations_updated_at
  BEFORE UPDATE ON organisations
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

-- Row Level Security
ALTER TABLE organisations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own organisations"
  ON organisations FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create organisations"
  ON organisations FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own organisations"
  ON organisations FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own organisations"
  ON organisations FOR DELETE
  USING (auth.uid() = user_id);
