# GrantCraft — AI-Powered Grant Application Platform

## Project Overview
GrantCraft helps Irish community organisations find and apply for grants. It guides users through a four-stage journey:
1. **Organisation Profile** — Capture org details, structure, capacity
2. **Idea Development** — Help users articulate project ideas with AI assistance
3. **Grant Matching** — Match org + idea against a database of ~76 Irish grant programmes
4. **Application Generation** — Generate draft applications tailored to each grant's requirements

## Tech Stack
- **Framework**: Next.js 14 (App Router)
- **Styling**: Tailwind CSS
- **Database**: Supabase (PostgreSQL + Auth + Storage)
- **AI**: Anthropic Claude API (via Vercel AI SDK)
- **Deployment**: Vercel

## Project Structure
```
src/
├── app/
│   ├── layout.tsx              # Root layout with providers
│   ├── page.tsx                # Landing/home page
│   ├── dashboard/
│   │   └── page.tsx            # User dashboard (list orgs, projects)
│   ├── org/
│   │   ├── new/page.tsx        # Create new organisation profile
│   │   └── [id]/
│   │       ├── page.tsx        # View/edit org profile
│   │       └── projects/       # Stage 2-4 routes (future)
│   └── api/
│       ├── org/route.ts        # Org CRUD endpoints
│       └── grants/route.ts     # Grant matching endpoints (future)
├── components/
│   ├── ui/                     # Reusable UI primitives (Button, Input, Select, etc.)
│   ├── org/                    # Organisation-specific components
│   │   ├── OrgProfileForm.tsx  # Multi-section org profile form
│   │   └── OrgCard.tsx         # Org summary card for dashboard
│   └── layout/                 # Layout components (Header, Sidebar, etc.)
├── lib/
│   ├── supabase/
│   │   ├── client.ts           # Browser Supabase client
│   │   ├── server.ts           # Server Supabase client
│   │   └── types.ts            # Generated DB types
│   ├── constants.ts            # Org types, counties, activity areas, etc.
│   └── utils.ts                # Shared utilities
├── types/
│   └── org.ts                  # Organisation TypeScript types
└── styles/
    └── globals.css             # Tailwind base + custom styles
```

## Current Stage: Stage 1 — Organisation Profile
Building the first screen users interact with. Captures everything needed to match orgs to grants later:
- Organisation identity (name, type, registration)
- Location (county, Eircode, rural/urban)
- Capacity (members, volunteers, annual budget)
- Activity areas and focus
- Previous grant experience

## Key Design Decisions
- **Multi-section form** with progress indicator, not a wizard — users can jump between sections
- **Auto-save to Supabase** on section completion (no lost work)
- **Irish-specific constants** — org types match Irish legal structures (CLG, CIC, unincorporated, etc.), counties use official list, activity areas align with common Irish grant categories
- **Grant-readiness score** — calculated from profile completeness, shown to motivate completion

## Database
Using Supabase PostgreSQL. Migrations in `supabase/migrations/`.
Row Level Security (RLS) enabled — users can only access their own organisations.

## Conventions
- Use TypeScript strictly (no `any`)
- Server Components by default, `'use client'` only when needed
- Tailwind for all styling, no CSS modules
- Supabase auth via `@supabase/ssr` package
- Form state with React `useState` + controlled inputs (keep it simple for now)
- Irish English spelling in UI copy (organisation, programme, etc.)
