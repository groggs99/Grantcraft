// Irish-specific constants for GrantCraft

import type { OrgType, OrgSetting, BudgetRange, GeographicReach, ProfileSection } from '@/types/org';

export const ORG_TYPE_LABELS: Record<OrgType, string> = {
  unincorporated_association: 'Unincorporated Association',
  company_limited_by_guarantee: 'Company Limited by Guarantee (CLG)',
  community_interest_company: 'Community Interest Company (CIC)',
  cooperative: 'Co-operative Society',
  registered_charity: 'Registered Charity',
  sports_club: 'Sports Club (GAA, Soccer, etc.)',
  school_education: 'School / Educational Body',
  public_body: 'Public Body / Local Authority',
  other: 'Other',
};

export const ORG_SETTING_LABELS: Record<OrgSetting, string> = {
  rural: 'Rural',
  urban: 'Urban',
  peri_urban: 'Peri-urban (town fringe)',
};

export const BUDGET_RANGE_LABELS: Record<BudgetRange, string> = {
  under_5k: 'Under €5,000',
  '5k_25k': '€5,000 – €25,000',
  '25k_100k': '€25,000 – €100,000',
  '100k_500k': '€100,000 – €500,000',
  over_500k: 'Over €500,000',
};

export const GEOGRAPHIC_REACH_LABELS: Record<GeographicReach, string> = {
  parish: 'Parish / Local Area',
  county: 'County-wide',
  regional: 'Regional (multi-county)',
  national: 'National',
};

export const COUNTIES = [
  'Carlow', 'Cavan', 'Clare', 'Cork', 'Donegal', 'Dublin',
  'Galway', 'Kerry', 'Kildare', 'Kilkenny', 'Laois', 'Leitrim',
  'Limerick', 'Longford', 'Louth', 'Mayo', 'Meath', 'Monaghan',
  'Offaly', 'Roscommon', 'Sligo', 'Tipperary', 'Waterford',
  'Westmeath', 'Wexford', 'Wicklow',
] as const;

export const ACTIVITY_AREAS = [
  { slug: 'sports_recreation', label: 'Sports & Recreation' },
  { slug: 'arts_culture', label: 'Arts, Culture & Heritage' },
  { slug: 'environment', label: 'Environment & Biodiversity' },
  { slug: 'community_development', label: 'Community Development' },
  { slug: 'youth', label: 'Youth Services' },
  { slug: 'older_people', label: 'Services for Older People' },
  { slug: 'disability', label: 'Disability Services' },
  { slug: 'health_wellbeing', label: 'Health & Wellbeing' },
  { slug: 'education_training', label: 'Education & Training' },
  { slug: 'social_enterprise', label: 'Social Enterprise' },
  { slug: 'housing', label: 'Housing & Homelessness' },
  { slug: 'migration_integration', label: 'Migration & Integration' },
  { slug: 'digital_inclusion', label: 'Digital Inclusion' },
  { slug: 'tourism', label: 'Tourism & Local Economy' },
  { slug: 'tidy_towns', label: 'Tidy Towns & Village Renewal' },
  { slug: 'food_agriculture', label: 'Food, Fisheries & Agriculture' },
  { slug: 'safety_resilience', label: 'Community Safety & Resilience' },
  { slug: 'mens_sheds', label: "Men's Sheds / Women's Groups" },
] as const;

export const TARGET_DEMOGRAPHICS = [
  { slug: 'general_community', label: 'General Community' },
  { slug: 'children', label: 'Children (under 12)' },
  { slug: 'young_people', label: 'Young People (12–25)' },
  { slug: 'older_adults', label: 'Older Adults (65+)' },
  { slug: 'families', label: 'Families' },
  { slug: 'women', label: 'Women & Girls' },
  { slug: 'men', label: 'Men & Boys' },
  { slug: 'people_with_disabilities', label: 'People with Disabilities' },
  { slug: 'migrants_refugees', label: 'Migrants & Refugees' },
  { slug: 'traveller_community', label: 'Traveller Community' },
  { slug: 'lgbtq', label: 'LGBTQ+ Community' },
  { slug: 'unemployed', label: 'Unemployed / Job Seekers' },
  { slug: 'rural_isolated', label: 'Rural & Isolated Communities' },
] as const;

// Profile sections for multi-section form navigation
export const PROFILE_SECTIONS: { key: ProfileSection; label: string; icon: string }[] = [
  { key: 'identity', label: 'Organisation Details', icon: 'Building2' },
  { key: 'location', label: 'Location', icon: 'MapPin' },
  { key: 'contact', label: 'Contact Person', icon: 'User' },
  { key: 'capacity', label: 'Capacity & Governance', icon: 'BarChart3' },
  { key: 'activities', label: 'Activities & Focus', icon: 'Target' },
  { key: 'grants', label: 'Grant Experience', icon: 'Award' },
];

// Default form values
export const DEFAULT_ORG_FORM_DATA = {
  name: '',
  org_type: 'unincorporated_association' as OrgType,
  org_type_other: '',
  description: '',
  year_established: undefined,
  website: '',
  is_registered_charity: false,
  charity_number: '',
  cro_number: '',
  county: '',
  town_area: '',
  eircode: '',
  setting: 'rural' as OrgSetting,
  contact_name: '',
  contact_email: '',
  contact_phone: '',
  contact_role: '',
  member_count: undefined,
  volunteer_count: undefined,
  paid_staff_count: 0,
  budget_range: undefined,
  has_bank_account: false,
  has_governance_docs: false,
  has_insurance: false,
  activity_areas: [] as string[],
  target_demographics: [] as string[],
  geographic_reach: undefined,
  has_previous_grants: false,
  previous_grant_details: '',
};
