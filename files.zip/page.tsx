'use client';

import { useRouter } from 'next/navigation';
import OrgProfileForm from '@/components/org/OrgProfileForm';
import type { OrgProfileFormData } from '@/types/org';
// import { createClient } from '@/lib/supabase/client';

export default function NewOrgPage() {
  const router = useRouter();

  const handleSave = async (data: OrgProfileFormData) => {
    // TODO: Replace with Supabase client once auth is wired up
    // const supabase = createClient();
    // const { data: { user } } = await supabase.auth.getUser();
    // const { error } = await supabase.from('organisations').insert({
    //   ...data,
    //   user_id: user!.id,
    //   profile_completeness: calcCompleteness(data),
    // });
    // if (error) throw error;
    // router.push('/dashboard');

    // For now: log to console
    console.log('Save org profile:', data);
    alert('Profile saved! (Supabase integration pending)');
  };

  return <OrgProfileForm onSave={handleSave} />;
}
