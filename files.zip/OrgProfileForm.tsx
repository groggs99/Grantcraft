'use client';

import { useState, useCallback } from 'react';
import {
  Building2, MapPin, User, BarChart3, Target, Award,
  ChevronRight, Check, Loader2, Save,
} from 'lucide-react';
import type { OrgProfileFormData, ProfileSection } from '@/types/org';
import {
  ORG_TYPE_LABELS, ORG_SETTING_LABELS, BUDGET_RANGE_LABELS,
  GEOGRAPHIC_REACH_LABELS, COUNTIES, ACTIVITY_AREAS, TARGET_DEMOGRAPHICS,
  PROFILE_SECTIONS, DEFAULT_ORG_FORM_DATA,
} from '@/lib/constants';

// ─── Icon map ───────────────────────────────────────────────
const ICON_MAP: Record<string, React.ElementType> = {
  Building2, MapPin, User, BarChart3, Target, Award,
};

// ─── Completeness calculation ───────────────────────────────
function calcCompleteness(data: OrgProfileFormData): number {
  const checks = [
    !!data.name,
    !!data.org_type,
    !!data.description && data.description.length > 20,
    !!data.county,
    !!data.town_area,
    !!data.contact_name,
    !!data.contact_email,
    data.member_count !== undefined && data.member_count > 0,
    !!data.budget_range,
    data.has_bank_account,
    data.has_governance_docs,
    data.activity_areas.length > 0,
    data.target_demographics.length > 0,
    !!data.geographic_reach,
  ];
  return Math.round((checks.filter(Boolean).length / checks.length) * 100);
}

// ─── Section completeness ───────────────────────────────────
function isSectionComplete(section: ProfileSection, data: OrgProfileFormData): boolean {
  switch (section) {
    case 'identity':
      return !!data.name && !!data.org_type && !!data.description;
    case 'location':
      return !!data.county && !!data.town_area;
    case 'contact':
      return !!data.contact_name && !!data.contact_email;
    case 'capacity':
      return !!data.budget_range && data.has_bank_account;
    case 'activities':
      return data.activity_areas.length > 0 && data.target_demographics.length > 0;
    case 'grants':
      return true; // Optional section
  }
}

// ═══════════════════════════════════════════════════════════════
// Main Form Component
// ═══════════════════════════════════════════════════════════════
interface OrgProfileFormProps {
  initialData?: Partial<OrgProfileFormData>;
  onSave: (data: OrgProfileFormData) => Promise<void>;
}

export default function OrgProfileForm({ initialData, onSave }: OrgProfileFormProps) {
  const [activeSection, setActiveSection] = useState<ProfileSection>('identity');
  const [formData, setFormData] = useState<OrgProfileFormData>({
    ...DEFAULT_ORG_FORM_DATA,
    ...initialData,
  });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const completeness = calcCompleteness(formData);

  // Generic field updater
  const updateField = useCallback(<K extends keyof OrgProfileFormData>(
    field: K,
    value: OrgProfileFormData[K]
  ) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setSaved(false);
  }, []);

  // Toggle item in array field
  const toggleArrayItem = useCallback((field: 'activity_areas' | 'target_demographics', slug: string) => {
    setFormData(prev => {
      const arr = prev[field];
      return {
        ...prev,
        [field]: arr.includes(slug) ? arr.filter(s => s !== slug) : [...arr, slug],
      };
    });
    setSaved(false);
  }, []);

  // Save handler
  const handleSave = async () => {
    setSaving(true);
    try {
      await onSave(formData);
      setSaved(true);
    } catch (err) {
      console.error('Save failed:', err);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-stone-50">
      {/* Header */}
      <header className="sticky top-0 z-10 border-b border-stone-200 bg-white/80 backdrop-blur-sm">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4">
          <div>
            <h1 className="text-xl font-semibold text-stone-900">Organisation Profile</h1>
            <p className="text-sm text-stone-500">
              Tell us about your organisation to find the best grants
            </p>
          </div>
          <div className="flex items-center gap-4">
            {/* Completeness ring */}
            <div className="flex items-center gap-2">
              <div className="relative h-10 w-10">
                <svg className="h-10 w-10 -rotate-90" viewBox="0 0 36 36">
                  <circle cx="18" cy="18" r="15.5" fill="none" stroke="#e7e5e4" strokeWidth="3" />
                  <circle
                    cx="18" cy="18" r="15.5" fill="none"
                    stroke={completeness >= 80 ? '#16a34a' : completeness >= 40 ? '#ca8a04' : '#dc2626'}
                    strokeWidth="3"
                    strokeDasharray={`${completeness} ${100 - completeness}`}
                    strokeLinecap="round"
                  />
                </svg>
                <span className="absolute inset-0 flex items-center justify-center text-xs font-bold text-stone-700">
                  {completeness}
                </span>
              </div>
              <span className="hidden text-xs text-stone-500 sm:block">Grant Ready</span>
            </div>
            <button
              onClick={handleSave}
              disabled={saving}
              className="flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-emerald-700 disabled:opacity-50"
            >
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : saved ? <Check className="h-4 w-4" /> : <Save className="h-4 w-4" />}
              {saving ? 'Saving…' : saved ? 'Saved' : 'Save'}
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-5xl px-6 py-8">
        <div className="flex gap-8">
          {/* Sidebar nav */}
          <nav className="hidden w-56 shrink-0 md:block">
            <ul className="space-y-1">
              {PROFILE_SECTIONS.map(({ key, label, icon }) => {
                const Icon = ICON_MAP[icon] ?? Building2;
                const isActive = activeSection === key;
                const isComplete = isSectionComplete(key, formData);
                return (
                  <li key={key}>
                    <button
                      onClick={() => setActiveSection(key)}
                      className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm transition ${
                        isActive
                          ? 'bg-emerald-50 font-medium text-emerald-800'
                          : 'text-stone-600 hover:bg-stone-100'
                      }`}
                    >
                      <Icon className={`h-4 w-4 ${isActive ? 'text-emerald-600' : 'text-stone-400'}`} />
                      <span className="flex-1">{label}</span>
                      {isComplete && (
                        <Check className="h-3.5 w-3.5 text-emerald-500" />
                      )}
                    </button>
                  </li>
                );
              })}
            </ul>
          </nav>

          {/* Form content */}
          <main className="min-w-0 flex-1">
            <div className="rounded-xl border border-stone-200 bg-white p-6 shadow-sm">
              {/* ─── Identity ─── */}
              {activeSection === 'identity' && (
                <SectionWrapper title="Organisation Details" description="Basic information about your group or organisation.">
                  <FormField label="Organisation Name" required>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={e => updateField('name', e.target.value)}
                      placeholder="e.g. Bettystown Community Development Association"
                      className="form-input"
                    />
                  </FormField>

                  <FormField label="Organisation Type" required>
                    <select
                      value={formData.org_type}
                      onChange={e => updateField('org_type', e.target.value as any)}
                      className="form-input"
                    >
                      {Object.entries(ORG_TYPE_LABELS).map(([val, label]) => (
                        <option key={val} value={val}>{label}</option>
                      ))}
                    </select>
                  </FormField>

                  {formData.org_type === 'other' && (
                    <FormField label="Please specify">
                      <input
                        type="text"
                        value={formData.org_type_other ?? ''}
                        onChange={e => updateField('org_type_other', e.target.value)}
                        className="form-input"
                      />
                    </FormField>
                  )}

                  <FormField label="Description" required hint="What does your organisation do? Who does it serve?">
                    <textarea
                      value={formData.description ?? ''}
                      onChange={e => updateField('description', e.target.value)}
                      rows={4}
                      placeholder="Briefly describe your organisation's mission and main activities…"
                      className="form-input resize-none"
                    />
                  </FormField>

                  <div className="grid gap-4 sm:grid-cols-2">
                    <FormField label="Year Established">
                      <input
                        type="number"
                        value={formData.year_established ?? ''}
                        onChange={e => updateField('year_established', e.target.value ? parseInt(e.target.value) : undefined)}
                        placeholder="e.g. 2015"
                        min={1800} max={2026}
                        className="form-input"
                      />
                    </FormField>
                    <FormField label="Website">
                      <input
                        type="url"
                        value={formData.website ?? ''}
                        onChange={e => updateField('website', e.target.value)}
                        placeholder="https://..."
                        className="form-input"
                      />
                    </FormField>
                  </div>

                  <div className="mt-2 space-y-3 rounded-lg bg-stone-50 p-4">
                    <p className="text-sm font-medium text-stone-700">Registration</p>
                    <CheckboxField
                      label="Registered Charity (on Charities Regulator register)"
                      checked={formData.is_registered_charity}
                      onChange={v => updateField('is_registered_charity', v)}
                    />
                    {formData.is_registered_charity && (
                      <FormField label="Charity Number (RCN)">
                        <input
                          type="text"
                          value={formData.charity_number ?? ''}
                          onChange={e => updateField('charity_number', e.target.value)}
                          placeholder="e.g. 20012345"
                          className="form-input"
                        />
                      </FormField>
                    )}
                    <FormField label="CRO Number (if registered company)">
                      <input
                        type="text"
                        value={formData.cro_number ?? ''}
                        onChange={e => updateField('cro_number', e.target.value)}
                        placeholder="e.g. 123456"
                        className="form-input"
                      />
                    </FormField>
                  </div>
                </SectionWrapper>
              )}

              {/* ─── Location ─── */}
              {activeSection === 'location' && (
                <SectionWrapper title="Location" description="Where is your organisation based? This helps match you to local and regional grants.">
                  <FormField label="County" required>
                    <select
                      value={formData.county}
                      onChange={e => updateField('county', e.target.value)}
                      className="form-input"
                    >
                      <option value="">Select county…</option>
                      {COUNTIES.map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </FormField>

                  <FormField label="Town / Area" required>
                    <input
                      type="text"
                      value={formData.town_area ?? ''}
                      onChange={e => updateField('town_area', e.target.value)}
                      placeholder="e.g. Bettystown"
                      className="form-input"
                    />
                  </FormField>

                  <FormField label="Eircode">
                    <input
                      type="text"
                      value={formData.eircode ?? ''}
                      onChange={e => updateField('eircode', e.target.value.toUpperCase())}
                      placeholder="e.g. A92 XY12"
                      maxLength={8}
                      className="form-input uppercase"
                    />
                  </FormField>

                  <FormField label="Setting" required>
                    <div className="flex gap-3">
                      {Object.entries(ORG_SETTING_LABELS).map(([val, label]) => (
                        <button
                          key={val}
                          type="button"
                          onClick={() => updateField('setting', val as any)}
                          className={`rounded-lg border px-4 py-2 text-sm transition ${
                            formData.setting === val
                              ? 'border-emerald-300 bg-emerald-50 font-medium text-emerald-800'
                              : 'border-stone-200 text-stone-600 hover:border-stone-300'
                          }`}
                        >
                          {label}
                        </button>
                      ))}
                    </div>
                  </FormField>
                </SectionWrapper>
              )}

              {/* ─── Contact ─── */}
              {activeSection === 'contact' && (
                <SectionWrapper title="Contact Person" description="Primary contact for grant correspondence.">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <FormField label="Full Name" required>
                      <input
                        type="text" value={formData.contact_name ?? ''}
                        onChange={e => updateField('contact_name', e.target.value)}
                        className="form-input"
                      />
                    </FormField>
                    <FormField label="Role in Organisation">
                      <input
                        type="text" value={formData.contact_role ?? ''}
                        onChange={e => updateField('contact_role', e.target.value)}
                        placeholder="e.g. Chairperson, Secretary"
                        className="form-input"
                      />
                    </FormField>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <FormField label="Email" required>
                      <input
                        type="email" value={formData.contact_email ?? ''}
                        onChange={e => updateField('contact_email', e.target.value)}
                        className="form-input"
                      />
                    </FormField>
                    <FormField label="Phone">
                      <input
                        type="tel" value={formData.contact_phone ?? ''}
                        onChange={e => updateField('contact_phone', e.target.value)}
                        placeholder="e.g. 087 123 4567"
                        className="form-input"
                      />
                    </FormField>
                  </div>
                </SectionWrapper>
              )}

              {/* ─── Capacity ─── */}
              {activeSection === 'capacity' && (
                <SectionWrapper title="Capacity & Governance" description="Helps us understand your organisation's scale and readiness for grant funding.">
                  <div className="grid gap-4 sm:grid-cols-3">
                    <FormField label="Members">
                      <input
                        type="number" min={0}
                        value={formData.member_count ?? ''}
                        onChange={e => updateField('member_count', e.target.value ? parseInt(e.target.value) : undefined)}
                        className="form-input"
                      />
                    </FormField>
                    <FormField label="Volunteers">
                      <input
                        type="number" min={0}
                        value={formData.volunteer_count ?? ''}
                        onChange={e => updateField('volunteer_count', e.target.value ? parseInt(e.target.value) : undefined)}
                        className="form-input"
                      />
                    </FormField>
                    <FormField label="Paid Staff">
                      <input
                        type="number" min={0}
                        value={formData.paid_staff_count}
                        onChange={e => updateField('paid_staff_count', parseInt(e.target.value) || 0)}
                        className="form-input"
                      />
                    </FormField>
                  </div>

                  <FormField label="Annual Budget Range" required>
                    <select
                      value={formData.budget_range ?? ''}
                      onChange={e => updateField('budget_range', e.target.value as any || undefined)}
                      className="form-input"
                    >
                      <option value="">Select range…</option>
                      {Object.entries(BUDGET_RANGE_LABELS).map(([val, label]) => (
                        <option key={val} value={val}>{label}</option>
                      ))}
                    </select>
                  </FormField>

                  <div className="space-y-3 rounded-lg bg-stone-50 p-4">
                    <p className="text-sm font-medium text-stone-700">Governance Readiness</p>
                    <p className="text-xs text-stone-500">
                      Many grant programmes require these. Ticking them improves your grant-readiness score.
                    </p>
                    <CheckboxField
                      label="Organisation has a dedicated bank account"
                      checked={formData.has_bank_account}
                      onChange={v => updateField('has_bank_account', v)}
                    />
                    <CheckboxField
                      label="Has a constitution or governing document"
                      checked={formData.has_governance_docs}
                      onChange={v => updateField('has_governance_docs', v)}
                    />
                    <CheckboxField
                      label="Has public liability insurance"
                      checked={formData.has_insurance}
                      onChange={v => updateField('has_insurance', v)}
                    />
                  </div>
                </SectionWrapper>
              )}

              {/* ─── Activities ─── */}
              {activeSection === 'activities' && (
                <SectionWrapper title="Activities & Focus" description="Select all areas your organisation is active in. This drives grant matching.">
                  <FormField label="Activity Areas" required hint="Select all that apply">
                    <div className="grid gap-2 sm:grid-cols-2">
                      {ACTIVITY_AREAS.map(({ slug, label }) => (
                        <TagToggle
                          key={slug}
                          label={label}
                          active={formData.activity_areas.includes(slug)}
                          onClick={() => toggleArrayItem('activity_areas', slug)}
                        />
                      ))}
                    </div>
                  </FormField>

                  <FormField label="Target Demographics" required hint="Who does your organisation primarily serve?">
                    <div className="grid gap-2 sm:grid-cols-2">
                      {TARGET_DEMOGRAPHICS.map(({ slug, label }) => (
                        <TagToggle
                          key={slug}
                          label={label}
                          active={formData.target_demographics.includes(slug)}
                          onClick={() => toggleArrayItem('target_demographics', slug)}
                        />
                      ))}
                    </div>
                  </FormField>

                  <FormField label="Geographic Reach">
                    <div className="flex flex-wrap gap-3">
                      {Object.entries(GEOGRAPHIC_REACH_LABELS).map(([val, label]) => (
                        <button
                          key={val} type="button"
                          onClick={() => updateField('geographic_reach', val as any)}
                          className={`rounded-lg border px-4 py-2 text-sm transition ${
                            formData.geographic_reach === val
                              ? 'border-emerald-300 bg-emerald-50 font-medium text-emerald-800'
                              : 'border-stone-200 text-stone-600 hover:border-stone-300'
                          }`}
                        >
                          {label}
                        </button>
                      ))}
                    </div>
                  </FormField>
                </SectionWrapper>
              )}

              {/* ─── Grant Experience ─── */}
              {activeSection === 'grants' && (
                <SectionWrapper title="Grant Experience" description="Optional — but helps us tailor recommendations to your experience level.">
                  <CheckboxField
                    label="Our organisation has received grant funding before"
                    checked={formData.has_previous_grants}
                    onChange={v => updateField('has_previous_grants', v)}
                  />
                  {formData.has_previous_grants && (
                    <FormField label="Previous Grants" hint="List any grants received — programme name, year, and amount if known.">
                      <textarea
                        value={formData.previous_grant_details ?? ''}
                        onChange={e => updateField('previous_grant_details', e.target.value)}
                        rows={4}
                        placeholder="e.g. LEADER Programme 2022 – €15,000 for community garden&#10;Sports Capital 2023 – €8,000 for pitch drainage"
                        className="form-input resize-none"
                      />
                    </FormField>
                  )}
                </SectionWrapper>
              )}

              {/* Section navigation */}
              <div className="mt-6 flex justify-between border-t border-stone-100 pt-4">
                <button
                  onClick={() => {
                    const idx = PROFILE_SECTIONS.findIndex(s => s.key === activeSection);
                    if (idx > 0) setActiveSection(PROFILE_SECTIONS[idx - 1].key);
                  }}
                  disabled={activeSection === PROFILE_SECTIONS[0].key}
                  className="text-sm text-stone-500 hover:text-stone-700 disabled:invisible"
                >
                  ← Previous
                </button>
                <button
                  onClick={() => {
                    const idx = PROFILE_SECTIONS.findIndex(s => s.key === activeSection);
                    if (idx < PROFILE_SECTIONS.length - 1) setActiveSection(PROFILE_SECTIONS[idx + 1].key);
                  }}
                  disabled={activeSection === PROFILE_SECTIONS[PROFILE_SECTIONS.length - 1].key}
                  className="flex items-center gap-1 text-sm font-medium text-emerald-600 hover:text-emerald-700 disabled:invisible"
                >
                  Next <ChevronRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// Sub-components
// ═══════════════════════════════════════════════════════════════

function SectionWrapper({ title, description, children }: {
  title: string; description: string; children: React.ReactNode;
}) {
  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-lg font-semibold text-stone-900">{title}</h2>
        <p className="mt-1 text-sm text-stone-500">{description}</p>
      </div>
      {children}
    </div>
  );
}

function FormField({ label, required, hint, children }: {
  label: string; required?: boolean; hint?: string; children: React.ReactNode;
}) {
  return (
    <label className="block space-y-1.5">
      <span className="text-sm font-medium text-stone-700">
        {label}
        {required && <span className="ml-0.5 text-red-400">*</span>}
      </span>
      {hint && <p className="text-xs text-stone-400">{hint}</p>}
      {children}
    </label>
  );
}

function CheckboxField({ label, checked, onChange }: {
  label: string; checked: boolean; onChange: (v: boolean) => void;
}) {
  return (
    <label className="flex cursor-pointer items-center gap-3">
      <input
        type="checkbox" checked={checked}
        onChange={e => onChange(e.target.checked)}
        className="h-4 w-4 rounded border-stone-300 text-emerald-600 focus:ring-emerald-500"
      />
      <span className="text-sm text-stone-700">{label}</span>
    </label>
  );
}

function TagToggle({ label, active, onClick }: {
  label: string; active: boolean; onClick: () => void;
}) {
  return (
    <button
      type="button" onClick={onClick}
      className={`rounded-lg border px-3 py-2 text-left text-sm transition ${
        active
          ? 'border-emerald-300 bg-emerald-50 font-medium text-emerald-800'
          : 'border-stone-200 text-stone-600 hover:border-stone-300 hover:bg-stone-50'
      }`}
    >
      {active && <Check className="mr-1.5 inline h-3.5 w-3.5" />}
      {label}
    </button>
  );
}
